package baller.example.hitchhikersweatherguidetoextraterrestialspace.fragments

import androidx.lifecycle.ViewModel

class WelcomeFragmentViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}