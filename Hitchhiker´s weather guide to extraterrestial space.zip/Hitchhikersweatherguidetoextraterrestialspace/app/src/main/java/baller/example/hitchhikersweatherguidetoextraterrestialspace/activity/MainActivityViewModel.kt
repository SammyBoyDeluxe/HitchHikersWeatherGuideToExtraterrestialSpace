package baller.example.hitchhikersweatherguidetoextraterrestialspace.activity

import androidx.lifecycle.ViewModel

class MainActivityViewModel : ViewModel() {

}
